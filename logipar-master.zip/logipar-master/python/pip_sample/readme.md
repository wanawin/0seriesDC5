# Python pip sample

1. `pip uninstall logipar`
2. `pip install logipar` (or just update it, whatevs.)
3. `python index.py`