# Logipar.py

Welcome to **Logipar**'s Python directory.  You may be interested in:
* [sample.py](sample.py) – An example using [logipar.py](logipar.py) (This sample matches those available in the JS and PHP targets)
* [logipar.py](logipar.py) – The actual python library, for direct use


**Logipar** for Python currently requires Python3.