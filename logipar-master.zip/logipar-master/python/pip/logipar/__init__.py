name = "logipar"
from logipar.logipar import Logipar, Token, Node
