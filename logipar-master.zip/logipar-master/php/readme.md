# Logipar.php

Welcome to **Logipar**'s PHP directory.  You may be interested in:
* [sample.php](sample.php) – An example using the **Logipar** PHAR (This sample matches those available in the JS and Python targets)
* [Logipar.phar](Logipar.phar) – The actual library, packaged into a PHAR for direct use
* [lib/](lib) – **Logipar**'s PHP source files