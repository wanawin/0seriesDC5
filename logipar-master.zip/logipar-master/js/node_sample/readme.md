# NPM / Node sample instructions

To be safe you can start by removing `node_modules` and `package-lock.json`, if they exist.

1. `npm uninstall logipar`
2. `npm install logipar`

Run `node index.js` to run the sample.